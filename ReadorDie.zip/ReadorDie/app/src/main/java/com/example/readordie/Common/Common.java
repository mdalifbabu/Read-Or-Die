package com.example.readordie.Common;

import com.example.readordie.Model.User;

public class Common {
    public static User currentUser;

}
