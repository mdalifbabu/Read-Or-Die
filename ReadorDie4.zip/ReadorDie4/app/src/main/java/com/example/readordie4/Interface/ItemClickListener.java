package com.example.readordie4.Interface;

import android.view.View;

public interface ItemClickListener {
   void onClick(View v, int adapterPosition);
}
