package com.example.readordie4.Common;

import com.example.readordie4.Model.User;
import com.example.readordie4.Model.User;

public class Common {
    public static User currentUser;

}
